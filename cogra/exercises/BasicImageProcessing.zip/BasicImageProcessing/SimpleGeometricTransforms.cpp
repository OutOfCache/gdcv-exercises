#include "SimpleGeometricTransforms.h"
#include <algorithm>
namespace GdCV
{

ImageRGB8 SimpleGeometricTransforms::flip(const ImageRGB8 & input)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::flop(const ImageRGB8 & input)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::flipflop(const ImageRGB8 & input)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::rotate90DegreesClockwise(const ImageRGB8 & input)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::rotate90DegreesAntiClockwise(const ImageRGB8 & input)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::rotate180Degrees(const ImageRGB8 & input)
{
  return flipflop(input);
}

ImageRGB8 SimpleGeometricTransforms::crop(const ImageRGB8 & input, 
                                          ui32vec2 & upperLeft, 
                                          ui32vec2 & lowerRight)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;

}

ImageRGB8 SimpleGeometricTransforms::upsample(const ImageRGB8 & input, const uint32 factor)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}

ImageRGB8 SimpleGeometricTransforms::downsample(const ImageRGB8 & input, const uint32 factor)
{
  // Assignment 2
  ImageRGB8 result(1, 1);
  return result;
}


}