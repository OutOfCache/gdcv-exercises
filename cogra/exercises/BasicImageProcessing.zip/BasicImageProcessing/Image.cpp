#include "Image.h"
namespace GdCV
{
// Assignment 1
// TODO Instantiate  templates 

}